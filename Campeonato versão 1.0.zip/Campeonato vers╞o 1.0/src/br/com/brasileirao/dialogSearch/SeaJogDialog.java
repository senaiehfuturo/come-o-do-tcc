
package br.com.brasileirao.dialogSearch;

import br.com.brasileirao.importacoes.CellRenderer;
import br.com.brasileirao.pessoas.Jogadoras;
import br.com.brasileirao.pessoasDAO.JogadorasDAO;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class SeaJogDialog extends javax.swing.JDialog {

    public SeaJogDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        txtConfirma.setVisible(false);
        DefaultTableModel model = (DefaultTableModel) tableTodos.getModel();
        tableTodos.setRowSorter(new TableRowSorter(model));
        tableTodos.setDefaultRenderer(Object.class, new CellRenderer());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ButtonFechar = new javax.swing.JButton();
        ButtonSearch = new javax.swing.JButton();
        txtConfirma = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableTodos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(820, 275));
        setMinimumSize(new java.awt.Dimension(820, 275));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        ButtonFechar.setBackground(new java.awt.Color(51, 51, 51));
        ButtonFechar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ButtonFechar.setForeground(new java.awt.Color(255, 218, 68));
        ButtonFechar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/fechar.png"))); // NOI18N
        ButtonFechar.setText("Fechar");
        ButtonFechar.setBorderPainted(false);
        ButtonFechar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ButtonFechar.setFocusPainted(false);
        ButtonFechar.setPreferredSize(new java.awt.Dimension(100, 32));
        ButtonFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonFecharActionPerformed(evt);
            }
        });

        ButtonSearch.setBackground(new java.awt.Color(51, 51, 51));
        ButtonSearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ButtonSearch.setForeground(new java.awt.Color(255, 218, 68));
        ButtonSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/list.png"))); // NOI18N
        ButtonSearch.setText("Buscar");
        ButtonSearch.setBorderPainted(false);
        ButtonSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ButtonSearch.setFocusPainted(false);
        ButtonSearch.setPreferredSize(new java.awt.Dimension(100, 32));
        ButtonSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSearchActionPerformed(evt);
            }
        });

        txtConfirma.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtConfirma.setText("Busca realizada com sucesso!");

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        tableTodos.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        tableTodos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NOME", "CPF", "IDADE", "QUALIDADE", "SALÁRIO", "TIME"
            }
        ));
        tableTodos.setGridColor(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(tableTodos);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(txtConfirma)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ButtonSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(ButtonFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonFechar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ButtonSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtConfirma))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setBounds(236, 416, 820, 275);
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonFecharActionPerformed
        this.dispose();
    }//GEN-LAST:event_ButtonFecharActionPerformed

    private void ButtonSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSearchActionPerformed
        DefaultTableModel model = (DefaultTableModel) tableTodos.getModel();
        
        JogadorasDAO jd = new JogadorasDAO();
        
        for(Jogadoras j:jd.getLista()){
            
            model.addRow(new Object[]{
                j.getNome(),
                j.getCpf(),
                j.getIdade(),
                j.getPosicao(),
                j.getSalario(),
                j.getTime()
            });
        }
        
        if(jd.isConfirma()) {
            txtConfirma.setVisible(true);
        }
        
    }//GEN-LAST:event_ButtonSearchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SeaJogDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SeaJogDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SeaJogDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SeaJogDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SeaJogDialog dialog = new SeaJogDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonFechar;
    private javax.swing.JButton ButtonSearch;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tableTodos;
    private javax.swing.JLabel txtConfirma;
    // End of variables declaration//GEN-END:variables
}
