
package br.com.brasileirao.principal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    
    private String usuario; private String senha;
    private boolean check = false; Connection dm;
    
    public Connection getConnection(){
        try {
            dm = DriverManager.getConnection("jdbc:mysql://localhost/CampeonatoBrasileiro", "root", "");
            setCheck(true);
            return dm;
            
        }catch(SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    
    }

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }
    
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
}
