 
package br.com.brasileirao.times;

import br.com.brasileirao.pessoas.Jogadoras;
import br.com.brasileirao.pessoas.ComissaoTecnica;
import java.util.ArrayList;

public class Times {

    private String nome;
    private String shortnome;
    private String estadio;
    private int pontuacao;
    private int id_times;
    private int vitoria; private int derrota; private int empate;
    private ArrayList <Jogadoras> jg = new ArrayList <>();//array para adicionar um objeto jogador ao time
    private ArrayList <ComissaoTecnica> ct = new ArrayList <>();//array para adicionar um objeto com ténica ao time
    private ArrayList <Partidas> pt = new ArrayList <>();//array para adicionar um objeto partida ao time
    
    public void add_jogadora(Jogadoras j) {//método que adiciona à array o objeto
        getJg().add(j);
    }
    
    public void add_comiTecnica(ComissaoTecnica c) {//método que adiciona à array o objeto
        getCt().add(c);
    }
    
    public void add_partida(Partidas p) {//método que adiciona à array o objeto
        getPt().add(p);
    }
    
    public void criar_time(String shortnome,String nome,String estadio) {//método para criar um time
        this.setNome(nome);
        this.setShortnome(shortnome);
        this.setEstadio(estadio);
    }
    
    public void pontuacao() {//calcula quanto o time pontou em todas as rodadas
        setPontuacao((this.getVitoria() * 3) + (this.getEmpate()));
    }
    
    public void mostrar_time() {
        this.pontuacao();
        System.out.println("\n--------------------------------------------------------------------");
        System.out.println("Time: "+this.getNome());
        System.out.println("Estádio: "+getEstadio());
        System.out.println("Pontuação: "+getPontuacao()+"\n\n");
        
        for(Jogadoras j:this.getJg()) {
            System.out.println("Nome Jogadora: "+j.getNome());
        }
        
        System.out.println("\n");
        
        for(ComissaoTecnica c:this.getCt()) {
            System.out.println("Nome Comissão Técnica: "+c.getNome());
        }
        
        System.out.println("\n");
        
        for(Partidas p:this.getPt()) {
            System.out.println("Local partida: "+this.getEstadio());
            p.mostrar_partida();
        }
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getShortnome() {
        return shortnome;
    }

    public void setShortnome(String shortnome) {
        this.shortnome = shortnome;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }
    
    public int getId_times() {
        return id_times;
    }

    public void setId_times(int id_times) {
        this.id_times = id_times;
    }
    
    public int getVitoria() {
        return vitoria;
    }

    public void setVitoria(int vitoria) {
        this.vitoria = vitoria;
    }

    public int getDerrota() {
        return derrota;
    }

    public void setDerrota(int derrota) {
        this.derrota = derrota;
    }

    public int getEmpate() {
        return empate;
    }

    public void setEmpate(int empate) {
        this.empate = empate;
    }

    public ArrayList <Jogadoras> getJg() {
        return jg;
    }

    public void setJg(ArrayList <Jogadoras> jg) {
        this.jg = jg;
    }

    public ArrayList <ComissaoTecnica> getCt() {
        return ct;
    }

    public void setCt(ArrayList <ComissaoTecnica> ct) {
        this.ct = ct;
    }

    public ArrayList <Partidas> getPt() {
        return pt;
    }

    public void setPt(ArrayList <Partidas> pt) {
        this.pt = pt;
    }
}