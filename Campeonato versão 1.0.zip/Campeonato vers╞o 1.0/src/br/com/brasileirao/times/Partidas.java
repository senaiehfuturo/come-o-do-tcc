
package br.com.brasileirao.times;

import java.util.Scanner;

public class Partidas {

    private Times t1; 
    private Times t2;
    private int rodada;
    private int placar1;
    private int placar2;
    private int id_partida;
        
    static Scanner sc = new Scanner(System.in);
    
    public void criar_partida(Times t1,Times t2,int rodada,int placar1,int placar2) {
        this.setT1(t1); this.setT2(t2);
        this.setRodada(rodada);
        this.setPlacar1(placar1); this.setPlacar2(placar2);
        this.resultado();
    }
    
    public void resultado() {
        if(getPlacar1()>getPlacar2()) {// se o time que estiver em casa estiver com mais gols, adiciona uma vitória para ele e
            //derrota para o que estiver jogando fora
            t1.setVitoria(t1.getVitoria() + 1); t2.setDerrota(t2.getDerrota() + 1);
        
        }else if(getPlacar2()>getPlacar1()) {//caso contrário ao primeiro if
            t2.setVitoria(t2.getVitoria() + 1); t1.setDerrota(t1.getDerrota() + 1);
        
        }else {//caso ocorra empate
            t1.setEmpate(t1.getEmpate() + 1);t2.setEmpate(t2.getEmpate() + 1);
        }
        
    }
    
    public void mostrar_partida() {
        System.out.println("Rodada "+this.getRodada()+": "
                +this.getT1().getShortnome()+" "+this.getPlacar1()+"X"+this.getPlacar2()+" "+this.getT2().getShortnome()+"\n");
    }
    
    public Times getT1() {
        return t1;
    }

    public void setT1(Times t1) {
        this.t1 = t1;
    }

    public Times getT2() {
        return t2;
    }

    public void setT2(Times t2) {
        this.t2 = t2;
    }

    public int getRodada() {
        return rodada;
    }

    public void setRodada(int rodada) {
        this.rodada = rodada;
    }

    public int getPlacar1() {
        return placar1;
    }

    public void setPlacar1(int placar1) {
        this.placar1 = placar1;
    }

    public int getPlacar2() {
        return placar2;
    }
    
    public void setPlacar2(int placar2) {
        this.placar2 = placar2;
    }
    
    public int getId_partida() {
        return id_partida;
    }
    
    public void setId_partida(int id_partida) {
        this.id_partida = id_partida;
    }
    
}