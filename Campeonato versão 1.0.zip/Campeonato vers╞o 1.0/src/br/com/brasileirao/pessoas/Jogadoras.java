
package br.com.brasileirao.pessoas;

import br.com.brasileirao.times.Partidas;

public class Jogadoras extends Pessoa {//herda características de pessoa

    private String posicao;
    private int amarelo; private int vermelho;
    private Partidas p; 
    private String time;
    
    public void criarPessoa(String cpf, String nome, int idade, String caract,String posicao, double salario, int verm, int amar, int id_times) {
        this.setCpf(cpf);
        this.setNome(nome);
        this.setIdade(idade);
        this.setCaract(caract);
        this.setPosicao(posicao);
        this.setSalario(salario);
        this.setAmarelo(amar);
        this.setVermelho(verm);
        this.setId_times(id_times);
    }
    
    public void salario() {//método para calcular o salário+comissão
        this.setComissao((getAmarelo() * -200.00)+(getVermelho() * -400.00));
        this.setSalario(this.getSalario() + this.getComissao());   
    }
    
    public void mostrarSimples() {
        System.out.println("\nCPF: "+this.getCpf()+"\nNome: "+this.getNome()
                +"\nIdade: "+this.getIdade()+"\nQualidade: "+this.getCaract()
                +"\nSalário por semana: "+this.getSalario()+"\nTime: "+this.getId_times());
    }
    
    public void mostrar_jogadoras() {
        this.salario();//simplifica o código na main, só precisando chamar um método
               
        System.out.println("Nome: "+this.getNome());
        System.out.println("CPF: "+this.getCpf());
        System.out.println("Idade: "+this.getIdade()+" anos");
        System.out.println("Posição: "+this.getPosicao());
        System.out.println("Qualidade: "+this.getCaract());
        System.out.println("Cartões amarelos: "+this.getAmarelo()+"\nCartões vermelhos: "+this.getVermelho());
        System.out.println("Salário base: "+(this.getSalario()-this.getComissao())+" R$"
                +"\nSalário + bônus: "+this.getSalario()+" R$");
    }
    
    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public int getAmarelo() {
        return amarelo;
    }

    public void setAmarelo(int amarelo) {
        this.amarelo = amarelo;
    }

    public int getVermelho() {
        return vermelho;
    }

    public void setVermelho(int vermelho) {
        this.vermelho = vermelho;
    }

    public Partidas getP() {
        return p;
    }

    public void setP(Partidas p) {
        this.p = p;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    
}