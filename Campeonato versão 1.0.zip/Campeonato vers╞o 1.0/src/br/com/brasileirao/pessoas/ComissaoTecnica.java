
package br.com.brasileirao.pessoas;

import br.com.brasileirao.times.Times;

public class ComissaoTecnica extends Pessoa {//herda características de pessoa

    private int cargo; private String funcao;
    private Times t;
    
    public void criarPessoa(String cpf, String nome, int idade, String caract, double salario,int id_times, String funcao) {
        this.setCpf(cpf);
        this.setNome(nome);
        this.setIdade(idade);
        this.setCaract(caract);
        this.setSalario(salario);
        this.setId_times(id_times);
        this.setFuncao(funcao);
    }
    
    public void salario() { //método para calcular o salário+comissão
        switch (getCargo()) {
            case 1:
                this.setComissao(4000);
                break;
            case 2:
                this.setComissao(2000);
                break;
            case 3:
                this.setComissao(3000);
                break;
            case 4:
                this.setComissao(4000);
                break;
            default:
                break;
        }
        
            this.setSalario(this.getSalario() + this.getComissao());
    }
    
    public void mostrar_ct() {//método para imprimir var da com. técnica
        this.salario();
        
        System.out.println("Nome: "+this.getNome());
        System.out.println("CPF: "+this.getCpf());
        System.out.println("Idade: "+this.getIdade());
            
        //analisa a opção inserida, para imprimir o cargo do funcionário
        switch (this.getCargo()) {
            case 1:
                System.out.println("Cargo: Técnica");
                break;
            case 2:
                System.out.println("Cargo: Aux. Técnica");
                break;
            case 3:
                System.out.println("Cargo: Prep. Física");
                break;
            case 4:
                System.out.println("Cargo: Médica");                   
                break;
            default:
                    break;
        }
            
        System.out.println("Qualidade: "+this.getCaract());
        System.out.println("Salário base: "+(this.getSalario()-this.getComissao())+" R$"+"\nSalário + bônus: "+this.getSalario()+" R$");
    }
    
    public int getCargo() {
        return cargo;
    }

    public void setCargo(int cargo) {
        this.cargo = cargo;
    }

    public Times getT() {
        return t;
    }
    
    public void setT(Times t){
        this.t = t;
    }
    
    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
}