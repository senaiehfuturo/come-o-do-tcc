
package br.com.brasileirao.pessoas;

import java.util.Scanner;//leitor que será usado no super.criar_pessoa

public abstract class Pessoa {//pode ser herdada

    private String cpf;
    private String nome;
    private int idade;
    private String caract;
    private double salario;
    private double comissao;
    private int id_times;
    private int id_pessoas;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCaract() {
        return caract;
    }

    public void setCaract(String caract) {
        this.caract = caract;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }

    public int getId_times() {
        return id_times;
    }
    
    public void setId_times(int id_times) {
        this.id_times = id_times;
    }
    
    public int getId_pessoas() {
        return id_pessoas;
    }
    
    public void setId_pessoas(int id_pessoas) {
        this.id_pessoas = id_pessoas;
    }
    
}
