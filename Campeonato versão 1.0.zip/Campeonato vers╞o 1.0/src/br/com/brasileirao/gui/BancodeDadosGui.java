
package br.com.brasileirao.gui;

public class BancodeDadosGui extends javax.swing.JFrame {
   
    AddDialog telaAdd = new AddDialog(new javax.swing.JFrame(), true); 
    DeleDialog telaDel = new DeleDialog(new javax.swing.JFrame(), true);
    SearchDialog telaCon = new SearchDialog(new javax.swing.JFrame(), true);
    UpdDialog telaAtu = new UpdDialog(new javax.swing.JFrame(), true);
    AjuDialog telaHelp = new AjuDialog(new javax.swing.JFrame(), true);
    
    public BancodeDadosGui() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        buttonAdicionar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        buttonDeletar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        buttonConsultar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        buttonAtualizar = new javax.swing.JButton();
        buttonAjuda = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        buttonSair = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(952, 524));
        setUndecorated(true);
        setResizable(false);
        setSize(new java.awt.Dimension(920, 460));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        buttonAdicionar.setBackground(new java.awt.Color(51, 51, 51));
        buttonAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/adicionar.png"))); // NOI18N
        buttonAdicionar.setBorderPainted(false);
        buttonAdicionar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonAdicionar.setFocusPainted(false);
        buttonAdicionar.setMaximumSize(new java.awt.Dimension(65, 40));
        buttonAdicionar.setMinimumSize(new java.awt.Dimension(65, 40));
        buttonAdicionar.setPreferredSize(new java.awt.Dimension(65, 40));
        buttonAdicionar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonAdicionarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonAdicionarMouseExited(evt);
            }
        });
        buttonAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAdicionarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Adicionar");

        buttonDeletar.setBackground(new java.awt.Color(51, 51, 51));
        buttonDeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/deletar.png"))); // NOI18N
        buttonDeletar.setBorderPainted(false);
        buttonDeletar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonDeletar.setFocusPainted(false);
        buttonDeletar.setMaximumSize(new java.awt.Dimension(65, 40));
        buttonDeletar.setMinimumSize(new java.awt.Dimension(65, 40));
        buttonDeletar.setPreferredSize(new java.awt.Dimension(65, 40));
        buttonDeletar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonDeletarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonDeletarMouseExited(evt);
            }
        });
        buttonDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDeletarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Deletar");

        buttonConsultar.setBackground(new java.awt.Color(51, 51, 51));
        buttonConsultar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/consultar.png"))); // NOI18N
        buttonConsultar.setBorderPainted(false);
        buttonConsultar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonConsultar.setFocusPainted(false);
        buttonConsultar.setMaximumSize(new java.awt.Dimension(65, 40));
        buttonConsultar.setMinimumSize(new java.awt.Dimension(65, 40));
        buttonConsultar.setPreferredSize(new java.awt.Dimension(65, 40));
        buttonConsultar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonConsultarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonConsultarMouseExited(evt);
            }
        });
        buttonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonConsultarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Consultar");

        buttonAtualizar.setBackground(new java.awt.Color(51, 51, 51));
        buttonAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/atualizar.png"))); // NOI18N
        buttonAtualizar.setBorderPainted(false);
        buttonAtualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonAtualizar.setFocusPainted(false);
        buttonAtualizar.setMaximumSize(new java.awt.Dimension(65, 40));
        buttonAtualizar.setMinimumSize(new java.awt.Dimension(65, 40));
        buttonAtualizar.setPreferredSize(new java.awt.Dimension(65, 40));
        buttonAtualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonAtualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonAtualizarMouseExited(evt);
            }
        });
        buttonAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAtualizarActionPerformed(evt);
            }
        });

        buttonAjuda.setBackground(new java.awt.Color(51, 51, 51));
        buttonAjuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/ajuda.png"))); // NOI18N
        buttonAjuda.setBorderPainted(false);
        buttonAjuda.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonAjuda.setFocusPainted(false);
        buttonAjuda.setMaximumSize(new java.awt.Dimension(65, 40));
        buttonAjuda.setMinimumSize(new java.awt.Dimension(65, 40));
        buttonAjuda.setPreferredSize(new java.awt.Dimension(65, 40));
        buttonAjuda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonAjudaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonAjudaMouseExited(evt);
            }
        });
        buttonAjuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAjudaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Atualizar");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Ajuda");

        buttonSair.setBackground(new java.awt.Color(51, 51, 51));
        buttonSair.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonSair.setForeground(new java.awt.Color(255, 255, 255));
        buttonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/sair32px.png"))); // NOI18N
        buttonSair.setBorderPainted(false);
        buttonSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonSair.setFocusPainted(false);
        buttonSair.setMaximumSize(new java.awt.Dimension(65, 40));
        buttonSair.setMinimumSize(new java.awt.Dimension(65, 40));
        buttonSair.setPreferredSize(new java.awt.Dimension(65, 40));
        buttonSair.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonSairMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonSairMouseExited(evt);
            }
        });
        buttonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonSairActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Sair");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonAdicionar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(buttonDeletar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(buttonConsultar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonAtualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonAjuda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonSair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(138, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(buttonDeletar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(buttonAdicionar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(buttonAjuda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonSair, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(541, 541, 541))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void buttonDeletarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonDeletarMouseExited
        buttonDeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/deletar.png")));
    }//GEN-LAST:event_buttonDeletarMouseExited

    private void buttonDeletarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonDeletarMouseEntered
        buttonDeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/deletar2.png")));
    }//GEN-LAST:event_buttonDeletarMouseEntered

    private void buttonAdicionarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAdicionarMouseExited
        buttonAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adicionar.png")));
    }//GEN-LAST:event_buttonAdicionarMouseExited

    private void buttonAdicionarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAdicionarMouseEntered
        buttonAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adicionar2.png")));
    }//GEN-LAST:event_buttonAdicionarMouseEntered

    private void buttonConsultarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonConsultarMouseEntered
        buttonConsultar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/consultar2.png")));
    }//GEN-LAST:event_buttonConsultarMouseEntered

    private void buttonConsultarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonConsultarMouseExited
        buttonConsultar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/consultar.png")));
    }//GEN-LAST:event_buttonConsultarMouseExited

    private void buttonAtualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAtualizarMouseEntered
        buttonAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/atualizar2.png")));
    }//GEN-LAST:event_buttonAtualizarMouseEntered

    private void buttonAtualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAtualizarMouseExited
        buttonAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/atualizar.png")));
    }//GEN-LAST:event_buttonAtualizarMouseExited

    private void buttonAjudaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAjudaMouseEntered
        buttonAjuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ajuda2.png")));
    }//GEN-LAST:event_buttonAjudaMouseEntered

    private void buttonAjudaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAjudaMouseExited
        buttonAjuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ajuda.png")));
    }//GEN-LAST:event_buttonAjudaMouseExited

    private void buttonSairMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonSairMouseEntered
        buttonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sair32px2.png")));
    }//GEN-LAST:event_buttonSairMouseEntered

    private void buttonSairMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonSairMouseExited
        buttonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sair32px.png")));
    }//GEN-LAST:event_buttonSairMouseExited

    private void buttonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_buttonSairActionPerformed

    private void buttonAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAdicionarActionPerformed
        if (telaDel.isVisible()) {
            telaDel.setVisible(false);
        
        }else if (telaCon.isVisible()) {
            telaCon.setVisible(false);
        
        }else if(telaAtu.isVisible()) {
            telaAtu.setVisible(false);
        
        }else if(telaHelp.isVisible()) {
            telaHelp.setVisible(false);
        }
        
        telaAdd.setVisible(true);
    }//GEN-LAST:event_buttonAdicionarActionPerformed

    private void buttonDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDeletarActionPerformed
        if (telaAdd.isVisible()) {
            telaAdd.setVisible(false);
        
        }else if (telaCon.isVisible()) {
            telaCon.setVisible(false);
        
        }else if(telaAtu.isVisible()) {
            telaAtu.setVisible(false);
        
        }else if(telaHelp.isVisible()) {
            telaHelp.setVisible(false);
        }
        
        telaDel.setVisible(true);
    }//GEN-LAST:event_buttonDeletarActionPerformed

    private void buttonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonConsultarActionPerformed
        if (telaAdd.isVisible()) {
            telaAdd.setVisible(false);
        
        }else if (telaDel.isVisible()) {
            telaDel.setVisible(false);
        
        }else if(telaAtu.isVisible()) {
            telaAtu.setVisible(false);
        
        }else if(telaHelp.isVisible()) {
            telaHelp.setVisible(false);
        }
        
        telaCon.setVisible(true);
    }//GEN-LAST:event_buttonConsultarActionPerformed

    private void buttonAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAtualizarActionPerformed
        if (telaAdd.isVisible()) {
            telaAdd.setVisible(false);
        
        }else if (telaDel.isVisible()) {
            telaDel.setVisible(false);
        
        }else if(telaCon.isVisible()) {
            telaCon.setVisible(false);
        
        }else if(telaHelp.isVisible()) {
            telaHelp.setVisible(false);
        }
        
        telaAtu.setVisible(true);
    }//GEN-LAST:event_buttonAtualizarActionPerformed

    private void buttonAjudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAjudaActionPerformed
        if (telaAdd.isVisible()) {
            telaAdd.setVisible(false);
        
        }else if (telaDel.isVisible()) {
            telaDel.setVisible(false);
        
        }else if(telaCon.isVisible()) {
            telaCon.setVisible(false);
        
        }else if(telaAtu.isVisible()) {
            telaAtu.setVisible(false);
        }
        
        telaHelp.setVisible(true);
    }//GEN-LAST:event_buttonAjudaActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BancodeDadosGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BancodeDadosGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BancodeDadosGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BancodeDadosGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BancodeDadosGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonAdicionar;
    private javax.swing.JButton buttonAjuda;
    private javax.swing.JButton buttonAtualizar;
    private javax.swing.JButton buttonConsultar;
    private javax.swing.JButton buttonDeletar;
    private javax.swing.JButton buttonSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
