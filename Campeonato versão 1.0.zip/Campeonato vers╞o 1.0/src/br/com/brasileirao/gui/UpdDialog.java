
package br.com.brasileirao.gui;

import br.com.brasileirao.dialogUpdate.*;
import java.awt.Color;

public class UpdDialog extends javax.swing.JDialog {
    
    UpdJogDialog sjd = new UpdJogDialog(new javax.swing.JFrame(), true);
    UpdTimesDialog std = new UpdTimesDialog(new javax.swing.JFrame(), true);
    UpdComTecDialog scd = new UpdComTecDialog(new javax.swing.JFrame(), true);
    UpdPartiDialog spd = new UpdPartiDialog(new javax.swing.JFrame(), true);

    public UpdDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jpTimes = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jpJogadoras = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jpComTec = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jpParti = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        buttonFechar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(930, 504));

        jLabel1.setFont(new java.awt.Font("Ebrima", 1, 24)); // NOI18N
        jLabel1.setText("Atualizar");

        jSeparator1.setForeground(new java.awt.Color(51, 51, 51));

        jpTimes.setBackground(new java.awt.Color(255, 255, 255));
        jpTimes.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpTimes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jpTimes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpTimesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jpTimesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jpTimesMouseExited(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 10)); // NOI18N
        jLabel2.setText("Abre caixa de diálogo para atualizar times");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/time.png"))); // NOI18N
        jLabel4.setText("Times");

        javax.swing.GroupLayout jpTimesLayout = new javax.swing.GroupLayout(jpTimes);
        jpTimes.setLayout(jpTimesLayout);
        jpTimesLayout.setHorizontalGroup(
            jpTimesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpTimesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpTimesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpTimesLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel2))
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpTimesLayout.setVerticalGroup(
            jpTimesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpTimesLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpJogadoras.setBackground(new java.awt.Color(255, 255, 255));
        jpJogadoras.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpJogadoras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jpJogadoras.setPreferredSize(new java.awt.Dimension(237, 72));
        jpJogadoras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpJogadorasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jpJogadorasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jpJogadorasMouseExited(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 10)); // NOI18N
        jLabel3.setText("Abre caixa de diálogo para atualizar jogadoras");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/jogadora.png"))); // NOI18N
        jLabel5.setText("Jogadoras");

        javax.swing.GroupLayout jpJogadorasLayout = new javax.swing.GroupLayout(jpJogadoras);
        jpJogadoras.setLayout(jpJogadorasLayout);
        jpJogadorasLayout.setHorizontalGroup(
            jpJogadorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpJogadorasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpJogadorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpJogadorasLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3))
                    .addComponent(jLabel5))
                .addContainerGap(163, Short.MAX_VALUE))
        );
        jpJogadorasLayout.setVerticalGroup(
            jpJogadorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpJogadorasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpComTec.setBackground(new java.awt.Color(255, 255, 255));
        jpComTec.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpComTec.setForeground(new java.awt.Color(255, 255, 255));
        jpComTec.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jpComTec.setPreferredSize(new java.awt.Dimension(272, 74));
        jpComTec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpComTecMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jpComTecMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jpComTecMouseExited(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/comTec.png"))); // NOI18N
        jLabel6.setText("Comissão Técnica");

        jLabel7.setFont(new java.awt.Font("SansSerif", 0, 10)); // NOI18N
        jLabel7.setText("Abre caixa de diálogo para atualizar Comissão Ténica");

        javax.swing.GroupLayout jpComTecLayout = new javax.swing.GroupLayout(jpComTec);
        jpComTec.setLayout(jpComTecLayout);
        jpComTecLayout.setHorizontalGroup(
            jpComTecLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpComTecLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpComTecLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpComTecLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel7))
                    .addComponent(jLabel6))
                .addContainerGap(127, Short.MAX_VALUE))
        );
        jpComTecLayout.setVerticalGroup(
            jpComTecLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpComTecLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addContainerGap())
        );

        jpParti.setBackground(new java.awt.Color(255, 255, 255));
        jpParti.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpParti.setForeground(new java.awt.Color(255, 255, 255));
        jpParti.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jpParti.setPreferredSize(new java.awt.Dimension(246, 74));
        jpParti.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpPartiMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jpPartiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jpPartiMouseExited(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/partida.png"))); // NOI18N
        jLabel8.setText("Partidas");

        jLabel9.setFont(new java.awt.Font("SansSerif", 0, 10)); // NOI18N
        jLabel9.setText("Abre caixa de diálogo para atualizar Partidas");

        javax.swing.GroupLayout jpPartiLayout = new javax.swing.GroupLayout(jpParti);
        jpParti.setLayout(jpPartiLayout);
        jpPartiLayout.setHorizontalGroup(
            jpPartiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpPartiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpPartiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpPartiLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel9))
                    .addComponent(jLabel8))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpPartiLayout.setVerticalGroup(
            jpPartiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpPartiLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));

        buttonFechar.setBackground(new java.awt.Color(255, 255, 255));
        buttonFechar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        buttonFechar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/fecharSimples.png"))); // NOI18N
        buttonFechar.setText("Fechar");
        buttonFechar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        buttonFechar.setBorderPainted(false);
        buttonFechar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        buttonFechar.setFocusPainted(false);
        buttonFechar.setPreferredSize(new java.awt.Dimension(100, 32));
        buttonFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonFecharActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonFechar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jpTimes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jpComTec, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jpParti, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
                            .addComponent(jpJogadoras, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)))
                    .addComponent(jSeparator2))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(buttonFechar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpTimes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpJogadoras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpComTec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpParti, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(272, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setBounds(220, 164, 930, 504);
    }// </editor-fold>//GEN-END:initComponents

    private void jpTimesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpTimesMouseClicked
        if (sjd.isVisible()) {
            sjd.dispose();

        }else if(scd.isVisible()){
            scd.dispose();

        }else if(spd.isVisible()){
            spd.dispose();
        }

        std.setVisible(true);
    }//GEN-LAST:event_jpTimesMouseClicked

    private void jpTimesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpTimesMouseEntered
        this.destTimesEntered();
    }//GEN-LAST:event_jpTimesMouseEntered

    private void jpTimesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpTimesMouseExited
        this.destTimesExited();
    }//GEN-LAST:event_jpTimesMouseExited

    private void jpJogadorasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpJogadorasMouseClicked
        if (std.isVisible()) {
            std.dispose();

        }else if(scd.isVisible()){
            scd.dispose();

        }else if(spd.isVisible()){
            spd.dispose();
        }

        sjd.setVisible(true);
    }//GEN-LAST:event_jpJogadorasMouseClicked

    private void jpJogadorasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpJogadorasMouseEntered
        this.destJogadorasEntered();
    }//GEN-LAST:event_jpJogadorasMouseEntered

    private void jpJogadorasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpJogadorasMouseExited
        this.destJogadorasExited();
    }//GEN-LAST:event_jpJogadorasMouseExited

    private void jpComTecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpComTecMouseClicked
        if (std.isVisible()) {
            std.dispose();

        }else if(sjd.isVisible()){
            sjd.dispose();

        }else if(spd.isVisible()){
            spd.dispose();
        }

        scd.setVisible(true);
    }//GEN-LAST:event_jpComTecMouseClicked

    private void jpComTecMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpComTecMouseEntered
        this.destComTecEntered();
    }//GEN-LAST:event_jpComTecMouseEntered

    private void jpComTecMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpComTecMouseExited
        this.destComtecExited();
    }//GEN-LAST:event_jpComTecMouseExited

    private void jpPartiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpPartiMouseClicked
        if (std.isVisible()) {
            std.dispose();

        }else if(sjd.isVisible()){
            sjd.dispose();

        }else if(scd.isVisible()){
            scd.dispose();
        }

        spd.setVisible(true);
    }//GEN-LAST:event_jpPartiMouseClicked

    private void jpPartiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpPartiMouseEntered
        this.destPartiEntered();
    }//GEN-LAST:event_jpPartiMouseEntered

    private void jpPartiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpPartiMouseExited
        this.destPartiExited();
    }//GEN-LAST:event_jpPartiMouseExited

    private void buttonFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonFecharActionPerformed
        this.dispose();
    }//GEN-LAST:event_buttonFecharActionPerformed

    public void destTimesEntered(){
        jpTimes.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        jpTimes.setBackground(new Color(245,245,245));
    }
    
    public void destTimesExited(){
        jpTimes.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpTimes.setBackground(Color.WHITE);
        
    }
    
    public void destJogadorasEntered(){
        jpJogadoras.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        jpJogadoras.setBackground(new Color(245,245,245));
        
    }
    
    public void destJogadorasExited(){
        jpJogadoras.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpJogadoras.setBackground(Color.WHITE);
        
    }
    
    public void destComTecEntered(){
        jpComTec.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        jpComTec.setBackground(new Color(245,245,245));
        
    }
    
    public void destComtecExited(){
        jpComTec.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpComTec.setBackground(Color.WHITE);
        
    }
    
    public void destPartiEntered(){
        jpParti.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        jpParti.setBackground(new Color(245,245,245));
        
    }
    
    public void destPartiExited(){
        jpParti.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jpParti.setBackground(Color.WHITE);
        
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UpdDialog dialog = new UpdDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonFechar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPanel jpComTec;
    private javax.swing.JPanel jpJogadoras;
    private javax.swing.JPanel jpParti;
    private javax.swing.JPanel jpTimes;
    // End of variables declaration//GEN-END:variables
}
