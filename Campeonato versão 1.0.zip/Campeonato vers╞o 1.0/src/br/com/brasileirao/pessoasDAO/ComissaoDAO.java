
package br.com.brasileirao.pessoasDAO;

import br.com.brasileirao.principal.Conexao;
import br.com.brasileirao.pessoas.ComissaoTecnica;
import br.com.brasileirao.times.Times;
import br.com.brasileirao.timesDAO.TimesDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ComissaoDAO {
    
    private Connection connection;//variável para chamar métodos do tipo Connection
    private boolean confirma = false;
        
    public ComissaoDAO(){//sobrecarga de construtor para criar uma conexão com o banco
        connection = new Conexao().getConnection();
    }
    
    public void addCT(ComissaoTecnica c) {//método para inserir uma integrante da ct ao banco de dados
        Times t = new Times();
        String sql = ("INSERT INTO ComissaoTecnica(cpf,nome,idade,qualidade,salario,"
                + "cargo,id_times) VALUES(?,?,?,?,?,?,?)");
        
        try {  
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            
            stmt.setString(1, c.getCpf());
            stmt.setString(2, c.getNome());
            stmt.setInt(3, c.getIdade());
            stmt.setString(4, c.getCaract());
            stmt.setDouble(5, c.getSalario());
            stmt.setString(6, c.getFuncao());
            stmt.setInt(7, c.getId_times());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
           
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println("Problema ao inserir comissão: "+e.getMessage());
        }
        
    }
    
    public void deleteCT(ComissaoTecnica c){//método para deletar uma integrante da CT do banco de dados
        String sql = ("DELETE FROM ComissaoTecnica WHERE cpf = ?");
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, c.getCpf());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
           
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }

    public ArrayList<ComissaoTecnica> getLista() {//método para "conseguir" todas integrantes encontradas no banco de dados
        ArrayList<ComissaoTecnica> ct = new ArrayList<>();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM ComissaoTecnica");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                ComissaoTecnica comt = new ComissaoTecnica();
                
                Times t = new Times();
                TimesDAO td = new TimesDAO();
                
                comt.criarPessoa(rs.getString("CPF"), rs.getString("nome"), 
                        rs.getInt("idade"), rs.getString("qualidade"), rs.getDouble("salario"), rs.getInt("id_times"), rs.getString("cargo"));
                t.setId_times(rs.getInt("id_times"));
                
                td.getNome(t);
                comt.setT(t);
                ct.add(comt);
            }
            setConfirma(true);
          
            stmt.execute();
            stmt.close();
            
            return ct;
            
        }catch(SQLException e) {//caso aconteça algum erro
             throw new RuntimeException(e);
        }
        
    }
    
    public void selectCT() {//método para mostrar todos as integrantes da CT encontradas no banco de dados
        ArrayList<ComissaoTecnica> t = this.getLista();
      
        for(ComissaoTecnica te : t){
            System.out.println("\nCPF : "+te.getCpf()+"\nNome: "
                    +te.getNome()+"\nIdade: "+te.getIdade()+"\nCargo: "+te.getFuncao()+"\nTime: "+te.getId_times());     
        }
        
    }
    
    public void updateCT(ComissaoTecnica ct) {//método para atualizar atributos da integrante da CT selecionada
        String sql = "UPDATE ComissaoTecnica  SET nome = ?, idade = ?, qualidade = ?, salario = ?,"
                + "cargo = ?, id_times = ? where cpf = ?";
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, ct.getNome());
            stmt.setInt(2, ct.getIdade());
            stmt.setString(3, ct.getCaract());
            stmt.setDouble(4, ct.getSalario());
            stmt.setString(5, ct.getFuncao());
            stmt.setInt(6, ct.getId_times());
            stmt.setString(7, ct.getCpf());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            e.getMessage();
        }
        
    }
    
    public void buscarCT(ComissaoTecnica ct) {//método para mostrar apenas uma integrante da CT
        ComissaoTecnica ct2 = new ComissaoTecnica();
        
        String sql = "SELECT * FROM ComissaoTecnica WHERE cpf = ?";
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, ct.getCpf());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                ct2.setCpf(rs.getString("cpf")); ct2.setNome(rs.getString("nome")); 
                ct2.setIdade(rs.getInt("idade")); ct2.setFuncao(rs.getString("cargo"));
                ct2.setSalario(rs.getDouble("salario")); ct2.setId_times(rs.getInt("id_times"));
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            e.getMessage();
        }
        
        System.out.println("\nCPF: "+ct2.getCpf()+"\nNome: "+ct2.getNome()
                +"\nIdade: "+ct2.getIdade()+"\nFunção: "+ct2.getFuncao()
                +"\nSalário por semana: "+ct2.getSalario()+"\nTime: "+ct2.getId_times());
    }
    
    public int GetId_comissaotec(ComissaoTecnica c) {
        
        try{
            String sql = "SELECT id_comissaotec FROM ComissaoTecnica WHERE cpf = ?";
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, c.getCpf());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                c.setId_pessoas(rs.getInt("id_comissaotec"));
            }
            
            stmt.execute();
            stmt.close();
          
        }catch (SQLException | RuntimeException e) {
            e.getMessage();
        }
        return c.getId_pessoas();
        
    }
    public Connection getConnection() {
        return this.connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean isConfirma() {
        return confirma;
    }

    public void setConfirma(boolean confirma) {
        this.confirma = confirma;
    }
       
}