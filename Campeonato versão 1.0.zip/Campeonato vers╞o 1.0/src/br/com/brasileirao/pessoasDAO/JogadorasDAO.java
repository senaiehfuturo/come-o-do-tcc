
package br.com.brasileirao.pessoasDAO;

import br.com.brasileirao.pessoas.Jogadoras;
import br.com.brasileirao.principal.Conexao;
import br.com.brasileirao.times.Times;
import br.com.brasileirao.timesDAO.TimesDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class JogadorasDAO {

    private Connection connection;//variável para chamar métodos do tipo Connection
    private boolean confirma = false;
        
    public JogadorasDAO(){//sobrecarga de construtor para criar uma conexão com o banco
        connection = new Conexao().getConnection();
    }
    
    public void addJogadora(Jogadoras j) {//método para inserir uma jogadora ao banco de dados
        String sql = ("INSERT INTO Jogadoras(cpf,nome,idade,posicao,amarelo,vermelho,qualidade,salario,Id_times) "
                + "VALUES(?,?,?,?,?,?,?,?,?)");
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, j.getCpf());
            stmt.setString(2, j.getNome());
            stmt.setInt(3, j.getIdade());
            stmt.setString(4, j.getPosicao());
            stmt.setInt(5, j.getAmarelo());
            stmt.setInt(6, j.getVermelho());
            stmt.setString(7, j.getCaract());
            stmt.setDouble(8, j.getSalario());
            stmt.setInt(9, j.getId_times());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            
            connection.close();
       
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }
    
    public void deleteJogadoras(Jogadoras j){//método para deletar uma jogadora do banco de dados
        String sql = ("DELETE FROM Jogadoras WHERE cpf = ?");
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, j.getCpf());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
        
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }

    public ArrayList<Jogadoras> getLista() {//método para "conseguir" todos as jogadoras no banco de dados
        ArrayList<Jogadoras> ja = new ArrayList<>();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM Jogadoras");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Jogadoras j = new Jogadoras();
                Times t = new Times(); 
                TimesDAO td = new TimesDAO();
                
                j.setCpf(rs.getString("cpf")); j.setNome(rs.getString("nome"));
                j.setIdade(rs.getInt("idade"));j.setPosicao(rs.getString("posicao"));
                j.setSalario(rs.getDouble("salario")); t.setId_times(rs.getInt("id_times"));
                
                String time = td.getNome(t); j.setTime(time);
                ja.add(j);
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
            return ja;
            
        }catch(SQLException e) {//caso aconteça algum erro
            throw new RuntimeException(e);
        }
        
    }
    
    public void selectJogadoras() {//método para mostrar todos as jogadoras encontradas no banco de dados
        ArrayList<Jogadoras> jj = this.getLista();
      
        for(Jogadoras jog : jj){
            System.out.println("\nCPF: "+jog.getCpf()+"\nNome: "
                    +jog.getNome()+"\nIdade: "+jog.getIdade()+"\nQualidade: "+jog.getCaract()
                    +"\nSalário: "+jog.getSalario()+"\nTime: "+jog.getId_times());
            System.out.println("\n--------------------------------------------------------------------");
        }
        
    }
    
    public void updateJogadoras(Jogadoras j) {//método para atualizar atributos da jogadora selecionada
        String sql = "UPDATE Jogadoras SET cpf = ?, nome = ?, idade = ?, posicao = ?,"
                + "amarelo = ?, vermelho = ?, qualidade = ?, salario = ?, id_times = ? WHERE cpf = ?";
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, j.getCpf());
            stmt.setString(2, j.getNome());
            stmt.setInt(3, j.getIdade());
            stmt.setString(4, j.getPosicao());
            stmt.setInt(5, j.getAmarelo());
            stmt.setInt(6, j.getVermelho());
            stmt.setString(7, j.getCaract());
            j.salario();
            stmt.setDouble(8, j.getSalario());
            stmt.setInt(9, j.getId_times());
            stmt.setString(10, j.getCpf());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            e.getMessage();
        }
        
    }
    
    public void buscarJogadoras(Jogadoras j) {//método para mostrar apenas uma jpgadora 
        String sql = "SELECT * FROM Jogadoras WHERE cpf = ?";
        
        Jogadoras j1 = new Jogadoras();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, j.getCpf());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                j1.criarPessoa(rs.getString("cpf"), rs.getString("nome"), rs.getInt("idade"),
                        rs.getString("qualidade"),rs.getString("posicao"), rs.getDouble("salario"), 
                        rs.getInt("vermelho"), rs.getInt("amarelo"), rs.getInt("id_times"));
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            e.getMessage();
        }
        j1.mostrarSimples();
    
    }
    
    public int getId_jogadoras(Jogadoras j) {
        try{
            String sql = "SELECT id_jogadoras FROM Jogadoras WHERE cpf = ?";
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, j.getCpf());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                j.setId_pessoas(rs.getInt("id_jogadoras"));
            }
            
            stmt.execute();
            stmt.close();
          
        }catch (SQLException | RuntimeException e) {
            e.getMessage();
        }
        return j.getId_pessoas();
        
    }
    
    public Connection getConnection() {
        return this.connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean isConfirma() {
        return confirma;
    }

    public void setConfirma(boolean confirma) {
        this.confirma = confirma;
    }
       
}
