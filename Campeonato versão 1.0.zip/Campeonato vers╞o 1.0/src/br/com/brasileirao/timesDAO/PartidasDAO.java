
package br.com.brasileirao.timesDAO;

import br.com.brasileirao.principal.Conexao;
import br.com.brasileirao.times.Partidas;
import br.com.brasileirao.times.Times;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PartidasDAO {
    
    private Connection connection;//variável para chamar métodos do tipo Connection
    TimesDAO times = null;
    private boolean confirma = false;
        
    public PartidasDAO(){//sobrecarga de construtor para criar uma conexão com o banco
        connection = new Conexao().getConnection();
    }
    
    public void addPartidas(Partidas p) {//método para inserir uma partida ao banco de dados
        String sql = ("INSERT INTO Partidas (placar1, placar2, rodada, id_times1, id_times2) VALUES (?,?,?,?,?)");
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setInt(1, p.getPlacar1());
            stmt.setInt(2, p.getPlacar2());
            stmt.setInt(3, p.getRodada());
            
            stmt.setInt(4, p.getT1().getId_times());
           
            stmt.setInt(5, p.getT2().getId_times());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
       
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }
    
    public void deletePartidas(Partidas p){//método para deletar uma partida do banco de dados
        this.GetId_partida(p);
        
        String sql = ("DELETE FROM Partidas WHERE id_partidas = ?");
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setInt(1, p.getId_partida());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
        
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }

    public ArrayList<Partidas> getLista() {//método para "conseguir" todos as partidas no banco de dados
        ArrayList<Partidas> pa = new ArrayList<>();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM Partidas");
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Partidas p = new Partidas(); Times t1 = new Times(); Times t2 = new Times(); TimesDAO td = new TimesDAO();
                
                t1.setId_times(rs.getInt("id_times1")); t2.setId_times(rs.getInt("id_times2"));
                td.getNome(t1); td.getNome(t2);
                
                p.criar_partida(t1, t2, rs.getInt("rodada"), rs.getInt("placar1"), rs.getInt("placar2"));
               
                pa.add(p);
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            
            return pa;
            
        }catch(SQLException e) {//caso aconteça algum erro
            throw new RuntimeException(e);
        }
        
    }
    
    public void selectPartidas() {//método para mostrar todos as partidas encontradas no banco de dados
        ArrayList<Partidas> pp = this.getLista();
      
        for(Partidas par : pp){
            par.mostrar_partida();
            System.out.println("\n--------------------------------------------------------------------");
        }
        
    }
    
    public void updatePartidas(Partidas p) {//método para atualizar atributos da partida selecionada
        String sql = "UPDATE Partidas SET placar1 = ?, placar2 = ? WHERE id_partidas = ?";
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setInt(1, p.getPlacar1());
            stmt.setInt(2, p.getPlacar2());
            stmt.setInt(3, this.GetId_partida(p));
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            e.getMessage();
        }
        
    }
    
    public void buscarPartidas(Partidas p) {//método para mostrar apenas uma partida 
        String sql = "SELECT * FROM Partidas WHERE id_partidas = ?";
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setInt(1, this.GetId_partida(p));
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                TimesDAO td = new TimesDAO(); Times t1 = new Times(); Times t2 = new Times();
                
                t1.setId_times(rs.getInt("id_times1")); t2.setId_times(rs.getInt("id_times2"));
                
                td.getNome(t1); td.getNome(t2);
                
                p.setId_partida(rs.getInt("id_partida")); p.setRodada(rs.getInt("rodada"));
                p.setPlacar1(rs.getInt("placar1")); p.setPlacar2(rs.getInt("placar2")); 
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            e.getMessage();
        }
        p.mostrar_partida();
    
    }
    
    public int GetId_partida(Partidas p) {
        String sql = "SELECT id_partidas FROM Partidas WHERE rodada = ?"
                + " AND id_times1 = ? AND id_times2 = ?";
        
        try{
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            
            stmt.setInt(1, p.getRodada());
            stmt.setInt(2, p.getT1().getId_times());
            stmt.setInt(3, p.getT2().getId_times());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                p.setId_partida(rs.getInt("id_partidas"));
            }
            
        }catch(SQLException | RuntimeException e) {
            e.getMessage();
        }
        return p.getId_partida();
    }
    
    public Connection getConnection() {
        return this.connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean isConfirma() {
        return confirma;
    }

    public void setConfirma(boolean confirma) {
        this.confirma = confirma;
    }
    
}
