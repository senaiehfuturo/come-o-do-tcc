
package br.com.brasileirao.timesDAO;

import br.com.brasileirao.principal.Conexao;
import br.com.brasileirao.times.Partidas;
import br.com.brasileirao.times.Times;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TimesDAO {
    
    private Connection connection;//variável para chamar métodos do tipo Connection
    private boolean confirma = false;
        
    public TimesDAO(){//sobrecarga de construtor para criar uma conexão com o banco
        connection = new Conexao().getConnection();
    }
    
    public void addTimes(Times t) {//método para inserir um time ao banco de dados
        String sql = ("INSERT INTO Times(shortnome,nome,estadio,pontuacao) VALUES(?,?,?,?)");
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, t.getShortnome());
            stmt.setString(2, t.getNome());
            stmt.setString(3, t.getEstadio());
            stmt.setInt(4, t.getPontuacao());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            this.getId_times(t);
           
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }
    
    public void deleteTime(Times t){//método para deletar um time do banco de dados
        String sql = ("DELETE FROM Times WHERE id_times = ?");
        int id = getId_times(t);
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setInt(1, id);
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
//            connection.close();
        
        } catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }

    public ArrayList<Times> getLista() {//método para "conseguir" todos os times encontrados no banco de dados
        ArrayList<Times> tm = new ArrayList<>();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM Times");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Times t = new Times();
                t.criar_time(rs.getString("shortnome"), rs.getString("nome"), rs.getString("estadio"));
                t.setId_times(rs.getInt("id_times"));
                tm.add(t);
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
            return tm;
            
        }catch(SQLException e) {//caso aconteça algum erro
            throw new RuntimeException(e);
        }
        
    }
    
    public void selectTimes() {//método para mostrar todos os times encontrados no banco de dados
        ArrayList<Times> t = this.getLista();
      
        for(Times te : t){
            System.out.println("\nId do time: "+te.getId_times()+"\nAbreviação: "+te.getShortnome()
                    +"\nNome: "+te.getNome()+"\nEstádio: "+te.getEstadio());
            System.out.println("\n--------------------------------------------------------------------");
        }
        
    }
    
    public void updateTimes(Times t) {//método para atualizar atributos do time selecionado
        String sql = "UPDATE Times SET nome = ?, estadio = ?, pontuacao = ? WHERE shortnome = ?";
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, t.getNome());
            stmt.setString(2, t.getEstadio());
            t.pontuacao();
            stmt.setInt(3, t.getPontuacao());
            stmt.setString(4, t.getShortnome());
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
    }
    
    public void buscarTimes(Times t) {//método para mostrar apenas um time localizado pelo sua PK
        String sql = "SELECT * FROM Times WHERE shortnome = ?";
        
        Times t1 = new Times();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, t.getShortnome());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                t1.criar_time(rs.getString("shortnome"), rs.getString("nome"), rs.getString("estadio"));
                t1.setPontuacao(rs.getInt("pontuacao"));
            }
            setConfirma(true);
            
            stmt.execute();
            stmt.close();
            connection.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println(e.getMessage());
        }
        
        System.out.println("Abreviação: "+t1.getShortnome()+"\nNome: "
                    +t1.getNome()+"\nEstádio: "+t1.getEstadio()+"\nPontuação: "+t1.getPontuacao());
    
    }
    
    public int getId_times(Times t) {//método para buscar o id do time
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT id_times FROM Times WHERE "
                    + "nome = ?");
            stmt.setString(1, t.getNome());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                t.setId_times(rs.getInt("id_times"));
            }
            
            stmt.execute();
            stmt.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println("Problema ao buscar id do time: "+e.getMessage());
        }
        return t.getId_times();
        
    }
    
    public void getPartidas(Times t) {
        
        int id = getId_times(t); Partidas p = new Partidas();
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM Partidas WHERE id_times1 = ?");
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {                
                p.setT1(t);
                
                p.setPlacar1(rs.getInt("placar1"));
                p.setPlacar2(rs.getInt("placar2"));
                
                p.resultado();
                t.pontuacao();
            }
            
        }catch(SQLException | RuntimeException e) {
            e.getMessage();
        }
    }
    
    public String getNome(Times t) {//método para buscar o id do time
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT nome FROM Times WHERE "
                    + "id_times = ?");
            stmt.setInt(1, t.getId_times());
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()) {
                t.setNome(rs.getString("nome"));
            }
            
            stmt.execute();
            stmt.close();
            
        }catch(SQLException | RuntimeException e) {//caso aconteça algum erro
            System.out.println("Problema ao buscar o nome do time: "+e.getMessage());
        }
        return t.getNome();
        
    }
    
    public Connection getConnection() {
        return this.connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean isConfirma() {
        return confirma;
    }

    public void setConfirma(boolean confirma) {
        this.confirma = confirma;
    }
       
}